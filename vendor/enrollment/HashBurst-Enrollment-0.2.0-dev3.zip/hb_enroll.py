#!/usr/bin/env python3
"""Operator CLI for persistent, read-only, file-based HashBurst node enrollment."""
from __future__ import annotations
import argparse
import getpass
import json
from pathlib import Path
import platform
import sys
import time
import warnings
import cryptography
from identity import Identity, VERSION, read_doc, write_doc, no_link
from wire import Refused, public_key, key_id
from enrollment import issue, respond, accept, confirm, revoke, export_saved, history_binding

def secret(prompt):
    # Never let getpass silently fall back to visible terminal input.
    with warnings.catch_warnings():
        warnings.simplefilter('error', getpass.GetPassWarning)
        return getpass.getpass(prompt)

def password(new=False):
    first = secret('Passphrase della chiave locale (minimo 16 caratteri): ')
    if len(first) < 16: raise Refused('PASSPHRASE_LENGTH')
    if new and first != secret('Ripeti la passphrase: '):
        raise Refused('PASSPHRASE_MISMATCH')
    return first.encode('utf-8')

def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--version', action='version', version=VERSION)
    sub = p.add_subparsers(dest='command', required=True)
    init = sub.add_parser('init')
    init.add_argument('--role', choices=['controller','node'],required=True)
    init.add_argument('--state', type=Path, required=True)
    init.add_argument('--public-out', type=Path, required=True)
    init.add_argument('--report', type=Path, required=True)
    status = sub.add_parser('status'); status.add_argument('--state',type=Path,required=True)
    status.add_argument('--report',type=Path)
    inspect = sub.add_parser('inspect-public'); inspect.add_argument('--file',type=Path,required=True)
    inspect.add_argument('--role',choices=['controller','node'],required=True)
    for name in ['challenge','respond','accept','confirm','revoke','export']:
        cmd = sub.add_parser(name); cmd.add_argument('--state',type=Path,required=True)
        cmd.add_argument('--out',type=Path,required=True)
        if name == 'challenge':
            cmd.add_argument('--node-public',type=Path,required=True)
            cmd.add_argument('--node-fingerprint',required=True)
            cmd.add_argument('--ttl',type=int,default=3600)
            cmd.add_argument('--history',type=Path)
        elif name in ('respond','confirm'):
            cmd.add_argument('--controller-public',type=Path,required=True)
            cmd.add_argument('--controller-fingerprint',required=True)
            cmd.add_argument('--'+('challenge' if name=='respond' else 'ack'),type=Path,required=True)
            if name=='respond': cmd.add_argument('--consent-read-only',action='store_true')
        elif name=='accept': cmd.add_argument('--response',type=Path,required=True)
        elif name=='revoke': cmd.add_argument('--node-fingerprint',required=True)
        else:
            cmd.add_argument('--kind',choices=['challenge','ack'],required=True)
            cmd.add_argument('--ref',required=True)
    return p

def precheck_output(path):
    no_link(path,False)
    if path.exists(): raise Refused('OUTPUT_EXISTS')
    no_link(path.parent)

def main(argv=None):
    args=parser().parse_args(argv)
    now=int(time.time())
    if args.command=='inspect-public':
        key=public_key(read_doc(args.file),args.role)
        print(json.dumps({'role':args.role,'fingerprint':key_id(key),
              'scope':'enrollment-read-only','out_of_band_verification_required':True},indent=2))
        return 0
    for field in ('out','public_out','report'):
        value=getattr(args,field,None)
        if value: precheck_output(value)
    if args.command=='init':
        if args.public_out.absolute() == args.report.absolute(): raise Refused('OUTPUT_PATH_COLLISION')
        obj, created=Identity.create(args.state,args.role,password(not args.state.exists()),now)
        write_doc(args.public_out,obj.public)
        report=dict(obj.status(), created_new_identity=created, identity_reopened_and_verified=True,
                    platform=platform.system(),python=platform.python_version(),cryptography=cryptography.__version__)
        write_doc(args.report,report)
        print(json.dumps(report,indent=2))
        print('IDENTITY_READY persistent_encrypted_key no_miner_changes')
        print('PUBLIC='+str(args.public_out)); print('REPORT='+str(args.report))
        return 0
    obj=Identity(args.state,password())
    if args.command=='status':
        result=obj.status()
        if args.report: write_doc(args.report,result)
        print(json.dumps(result,indent=2)); return 0
    if args.command=='challenge':
        binding=None
        if args.history:
            print('Associazione dichiarata dall\'operatore, non attestazione del sensore. Nessun dato raw sara esportato.')
            binding=history_binding(args.history, secret('Campo API user: '),secret('Campo API worker: '),secret('Campo API machinename: '))
        result=issue(obj,read_doc(args.node_public),args.node_fingerprint,now,args.ttl,binding)
    elif args.command=='respond':
        result=respond(obj,read_doc(args.controller_public),args.controller_fingerprint,
                       read_doc(args.challenge),now,args.consent_read_only)
    elif args.command=='accept': result=accept(obj,read_doc(args.response),now)
    elif args.command=='confirm': result=confirm(obj,read_doc(args.controller_public),args.controller_fingerprint,read_doc(args.ack),now)
    elif args.command=='revoke': result=revoke(obj,args.node_fingerprint,now)
    else: result=export_saved(obj,args.kind,args.ref)
    write_doc(args.out,result)
    # Avoid printing pseudonymous worker bindings in the shareable terminal summary.
    print(json.dumps({'command':args.command,'completed':True,'scope':'enrollment-read-only',
                      'production_apply_supported':False,'network_calls':0,'miner_configuration_modified':False},indent=2))
    print('OUTPUT='+str(args.out)); return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except Refused as exc:
        print('STOP: '+exc.code,file=sys.stderr); raise SystemExit(2)
    except (EOFError,KeyboardInterrupt,getpass.GetPassWarning):
        print('STOP: INTERACTIVE_INPUT_REQUIRED_OR_CANCELLED',file=sys.stderr); raise SystemExit(2)
    except Exception as exc:
        # No raw filename, supplied URL, key contents or password in an error report.
        print('STOP: LOCAL_OPERATION_FAILED '+type(exc).__name__+'; retain state, do not regenerate identities.',file=sys.stderr)
        raise SystemExit(3)
