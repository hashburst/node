$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Root = $PSScriptRoot
$Seen = @{}
foreach ($Line in (Get-Content -LiteralPath (Join-Path $Root 'SHA256SUMS'))) {
    if ($Line -notmatch '^([0-9a-f]{64})  ([A-Za-z0-9_./-]+)$') {
        throw 'Manifest non valido.'
    }
    $Expected = $Matches[1]
    $Name = $Matches[2]
    if ($Name.StartsWith('/') -or (($Name -split '/') -contains '..') -or $Seen.ContainsKey($Name)) {
        throw 'Percorso o voce duplicata nel manifest.'
    }
    $Seen[$Name] = $true
    $File = Join-Path $Root $Name
    if (-not (Test-Path -LiteralPath $File -PathType Leaf)) { throw "File mancante: $Name" }
    $Actual = (Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Actual -ne $Expected) { throw "Checksum non corrispondente: $Name" }
}
foreach ($Name in @('wire.py', 'identity.py', 'enrollment.py', 'hb_enroll.py',
                   'Start-Identity.ps1', 'Verify-Package.ps1', 'requirements.txt',
                   'tests/test_enrollment.py', 'README.md', 'PROVENANCE.json')) {
    if (-not $Seen.ContainsKey($Name)) { throw "Manifest incompleto: $Name" }
}
Write-Host 'PACKAGE_INTEGRITY_OK'
