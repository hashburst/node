import copy
from contextlib import closing, redirect_stdout
from concurrent.futures import ThreadPoolExecutor
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import secrets
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from wire import *
from identity import Identity, read_doc, write_doc, write_new
from enrollment import *
import hb_enroll

PASSWORD=b'Test-only identity passphrase 2026'
NOW=1792967000

class EnrollmentTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.c,_=Identity.create(self.root/'controller','controller',PASSWORD,NOW)
        self.n,_=Identity.create(self.root/'node','node',PASSWORD,NOW)
    def tearDown(self): self.tmp.cleanup()
    def challenge(self,binding=None,ttl=3600):
        return issue(self.c,self.n.public,self.n.id,NOW+1,ttl,binding)
    def response(self,binding=None):
        ch=self.challenge(binding)
        return ch,respond(self.n,self.c.public,self.c.id,ch,NOW+2,True)
    def refusal(self,code,fn,*args,**kwargs):
        with self.assertRaises(Refused) as e: fn(*args,**kwargs)
        self.assertEqual(e.exception.code,code)
    def binding(self): return {'namespace':'1'*64,'worker':'2'*64,'assurance':'operator_asserted_not_telemetry_attested'}

    def test_encrypted_key_reopens_same_identity(self):
        pem=(self.c.path/'private-key.pem').read_bytes()
        self.assertTrue(pem.startswith(b'-----BEGIN ENCRYPTED PRIVATE KEY-----'))
        self.assertEqual(Identity(self.c.path,PASSWORD).id,self.c.id)
        with self.assertRaises(TypeError): serialization.load_pem_private_key(pem,None)
    def test_init_idempotent_never_regenerates(self):
        before={p.name:p.read_bytes() for p in self.c.path.iterdir()}
        other,created=Identity.create(self.c.path,'controller',PASSWORD,NOW+100)
        self.assertFalse(created); self.assertEqual(other.id,self.c.id)
        self.assertEqual(before,{p.name:p.read_bytes() for p in self.c.path.iterdir()})
    def test_wrong_password(self):
        self.refusal('KEY_UNLOCK_FAILED',Identity,self.c.path,b'Wrong test-only identity passphrase')
    def test_short_password(self):
        self.refusal('PASSPHRASE_LENGTH',Identity.create,self.root/'bad','node',b'abc',NOW)
        self.assertFalse((self.root/'bad').exists())
    def test_role_mismatch_never_replaces_key(self):
        before=(self.c.path/'private-key.pem').read_bytes()
        self.refusal('EXISTING_ROLE_MISMATCH',Identity.create,self.c.path,'node',PASSWORD,NOW)
        self.assertEqual(before,(self.c.path/'private-key.pem').read_bytes())
    def test_missing_registry_not_initialized(self):
        (self.c.path/'registry.sqlite').unlink()
        self.refusal('PATH_MISSING',Identity,self.c.path,PASSWORD)
        self.assertFalse((self.c.path/'registry.sqlite').exists())
    def test_wrong_public_key_rejected(self):
        (self.c.path/'public.json').write_bytes(canonical(self.n.public))
        self.refusal('KEY_PUBLIC_MISMATCH',Identity,self.c.path,PASSWORD)
    def test_unencrypted_private_key_rejected(self):
        raw=self.c.key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
        (self.c.path/'private-key.pem').write_bytes(raw)
        self.refusal('UNENCRYPTED_KEY_REFUSED',Identity,self.c.path,PASSWORD)
    def test_registry_identity_mismatch(self):
        with self.c.db(True) as db: db.execute("UPDATE meta SET v='bad' WHERE k='key_id'")
        self.refusal('REGISTRY_IDENTITY_MISMATCH',Identity,self.c.path,PASSWORD)
    def test_status_no_secrets_or_worker_ids(self):
        self.response(self.binding())
        s=self.c.status(); text=json.dumps(s)
        self.assertNotIn('private-key.pem',text); self.assertNotIn(PASSWORD.decode(),text)
        self.assertNotIn('2'*64,text)
        self.assertFalse(s['production_apply_supported']); self.assertFalse(s['telemetry_authenticated'])
    def test_roundtrip_enrollment_and_reopen(self):
        ch,r=self.response(self.binding())
        self.c=Identity(self.c.path,PASSWORD)
        ack=accept(self.c,r,NOW+3)
        self.n=Identity(self.n.path,PASSWORD)
        report=confirm(self.n,self.c.public,self.c.id,ack,NOW+4)
        self.assertTrue(report['identity_registry_confirmed'])
        self.assertEqual(self.c.status()['active_nodes'],1)
        self.assertEqual(report['binding_assurance'],'operator_asserted_not_telemetry_attested')
        self.assertFalse(report['telemetry_authenticated'])
    def test_no_binding_is_explicit(self):
        _,r=self.response(); a=accept(self.c,r,NOW+3)
        report=confirm(self.n,self.c.public,self.c.id,a,NOW+4)
        self.assertEqual(report['binding_assurance'],'not_bound')
        self.assertFalse(report['worker_binding_present'])
    def test_wrong_node_pin(self):
        self.refusal('PIN_MISMATCH',issue,self.c,self.n.public,'0'*64,NOW+1)
    def test_wrong_controller_pin(self):
        self.refusal('PIN_MISMATCH',respond,self.n,self.c.public,'0'*64,self.challenge(),NOW+2,True)
    def test_self_signed_public_role_mismatch(self):
        self.refusal('PUBLIC_ROLE_OR_SCOPE',issue,self.c,self.c.public,self.c.id,NOW+1)
    def test_public_doc_tampering(self):
        bad=copy.deepcopy(self.n.public); bad['payload']['created_at']+=1
        self.refusal('SIGNATURE_INVALID',issue,self.c,bad,self.n.id,NOW+1)
    def test_wrong_node_recipient(self):
        n2,_=Identity.create(self.root/'node2','node',PASSWORD,NOW)
        self.refusal('WRONG_RECIPIENT',respond,n2,self.c.public,self.c.id,self.challenge(),NOW+2,True)
    def test_consent_required(self):
        self.refusal('READ_ONLY_CONSENT_REQUIRED',respond,self.n,self.c.public,self.c.id,self.challenge(),NOW+2,False)
    def test_consent_must_be_bool(self):
        self.refusal('READ_ONLY_CONSENT_REQUIRED',respond,self.n,self.c.public,self.c.id,self.challenge(),NOW+2,1)
    def test_response_is_idempotent_before_expiry(self):
        ch,r=self.response()
        self.assertEqual(r,respond(self.n,self.c.public,self.c.id,ch,NOW+3,True))
        with self.n.db() as db: self.assertEqual(db.execute('SELECT count(*) FROM events').fetchone()[0],1)
    def test_replay_after_controller_reopen_rejected(self):
        _,r=self.response(); accept(self.c,r,NOW+3)
        c=Identity(self.c.path,PASSWORD)
        self.refusal('CHALLENGE_ALREADY_CONSUMED',accept,c,r,NOW+4)
    def test_pending_challenge_not_silently_replaced(self):
        self.challenge()
        self.refusal('PENDING_CHALLENGE_EXISTS',issue,self.c,self.n.public,self.n.id,NOW+2)
    def test_expired_pending_can_be_replaced(self):
        old=self.challenge(ttl=60)
        new=issue(self.c,self.n.public,self.n.id,NOW+62)
        self.assertNotEqual(old['payload']['nonce'],new['payload']['nonce'])
    def test_expiry_boundary_at_node(self):
        ch=self.challenge(ttl=60)
        self.refusal('EXPIRED',respond,self.n,self.c.public,self.c.id,ch,NOW+61,True)
    def test_expiry_at_controller(self):
        _,r=self.response()
        self.refusal('EXPIRED',accept,self.c,r,NOW+3601)
    def test_future_challenge(self):
        ch=issue(self.c,self.n.public,self.n.id,NOW+100)
        self.refusal('FUTURE_MESSAGE',respond,self.n,self.c.public,self.c.id,ch,NOW+2,True)
    def test_clock_rollback(self):
        _,r=self.response()
        self.refusal('CLOCK_ROLLBACK',accept,self.c,r,NOW-1)
    def test_max_ttl(self):
        self.refusal('INTEGER_INVALID',issue,self.c,self.n.public,self.n.id,NOW+1,86401)
    def test_boolean_ttl(self):
        self.refusal('INTEGER_INVALID',issue,self.c,self.n.public,self.n.id,NOW+1,True)
    def test_signature_tampering_not_consumed(self):
        ch,r=self.response(); bad=copy.deepcopy(r); bad['signature']='0'*128
        self.refusal('SIGNATURE_INVALID',accept,self.c,bad,NOW+3)
        self.assertEqual(accept(self.c,r,NOW+3)['kind'],'ack')
    def test_challenge_hash_tampering(self):
        _,r=self.response(); p=copy.deepcopy(r['payload']); p['challenge_sha256']='0'*64
        self.refusal('RESPONSE_CHALLENGE_MISMATCH',accept,self.c,sign(self.n.key,'response',p),NOW+3)
    def test_response_wrong_signer_not_accepted_from_input(self):
        _,r=self.response()
        self.refusal('SIGNER_MISMATCH',accept,self.c,sign(Ed25519PrivateKey.generate(),'response',r['payload']),NOW+3)
    def test_extra_command_field_refused(self):
        _,r=self.response(); p=copy.deepcopy(r['payload']); p['command']='start-miner'
        self.refusal('RESPONSE_SCHEMA',accept,self.c,sign(self.n.key,'response',p),NOW+3)
    def test_production_scope_refused(self):
        _,r=self.response(); p=copy.deepcopy(r['payload']); p['scope']='production'
        self.refusal('READ_ONLY_CONSENT_REQUIRED',accept,self.c,sign(self.n.key,'response',p),NOW+3)
    def test_lab_envelope_not_accepted(self):
        _,r=self.response(); r['format']='hb-control-lab-envelope-v1'
        self.refusal('DOMAIN_MISMATCH',accept,self.c,r,NOW+3)
    def test_no_command_message_kind(self):
        self.refusal('MESSAGE_KIND',sign,self.c.key,'plan',{})
    def test_other_controller_not_silently_trusted(self):
        self.response()
        c2,_=Identity.create(self.root/'ctl2','controller',PASSWORD,NOW)
        ch=issue(c2,self.n.public,self.n.id,NOW+3)
        self.refusal('OTHER_CONTROLLER_ALREADY_PINNED',respond,self.n,c2.public,c2.id,ch,NOW+4,True)
    def test_worker_binding_not_silently_reassigned(self):
        _,r=self.response(self.binding()); accept(self.c,r,NOW+3)
        n2,_=Identity.create(self.root/'n2','node',PASSWORD,NOW)
        self.refusal('WORKER_ALREADY_BOUND',issue,self.c,n2.public,n2.id,NOW+4,3600,self.binding())
    def test_claim_cannot_be_promoted_to_attestation(self):
        b=self.binding(); b['assurance']='cryptographically_verified_sensor'
        self.refusal('BINDING_ASSURANCE',self.challenge,b)
    def test_atomic_accept_rollback_on_sign_failure(self):
        _,r=self.response()
        with patch('enrollment.sign',side_effect=RuntimeError('test failure')):
            with self.assertRaises(RuntimeError): accept(self.c,r,NOW+3)
        self.assertEqual(self.c.status()['active_nodes'],0)
        accept(self.c,r,NOW+3)
    def test_atomic_accept_rollback_on_system_exit(self):
        _,r=self.response()
        with patch.object(self.c,'event',side_effect=SystemExit('test crash')):
            with self.assertRaises(SystemExit): accept(self.c,r,NOW+3)
        self.assertEqual(self.c.status()['active_nodes'],0)
        accept(self.c,r,NOW+3)
    def test_concurrent_accept_commits_once(self):
        _,r=self.response()
        def run():
            try: accept(self.c,r,NOW+3); return 'ok'
            except Refused as e: return e.code
        with ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(lambda _:run(),range(2)))
        self.assertEqual(sorted(results),['CHALLENGE_ALREADY_CONSUMED','ok'])
    def test_ack_preserves_read_only_scope(self):
        _,r=self.response(); ack=accept(self.c,r,NOW+3)
        self.assertEqual(ack['payload']['authorization'],'identity_registry_only')
        self.assertIs(ack['payload']['production_apply_supported'],False)
    def test_ack_with_execution_permission_rejected(self):
        _,r=self.response(); ack=accept(self.c,r,NOW+3)
        p=ack['payload'].copy(); p['production_apply_supported']=True
        self.refusal('ACK_SCOPE',confirm,self.n,self.c.public,self.c.id,sign(self.c.key,'ack',p),NOW+4)
    def test_ack_wrong_response(self):
        _,r=self.response(); a=accept(self.c,r,NOW+3); p=a['payload'].copy(); p['response_sha256']='0'*64
        self.refusal('ACK_RESPONSE_MISMATCH',confirm,self.n,self.c.public,self.c.id,sign(self.c.key,'ack',p),NOW+4)
    def test_ack_confirmation_idempotent(self):
        _,r=self.response(); a=accept(self.c,r,NOW+3)
        self.assertEqual(confirm(self.n,self.c.public,self.c.id,a,NOW+4),confirm(self.n,self.c.public,self.c.id,a,NOW+5))
    def test_saved_documents_recoverable_without_reissuing(self):
        ch,r=self.response(); a=accept(self.c,r,NOW+3)
        self.assertEqual(ch,export_saved(self.c,'challenge',ch['payload']['nonce']))
        self.assertEqual(a,export_saved(self.c,'ack',self.n.id))
    def test_revocation_is_local_durable_no_reenroll(self):
        _,r=self.response(); accept(self.c,r,NOW+3)
        rev=revoke(self.c,self.n.id,NOW+4)
        self.assertFalse(rev['remote_notification_sent'])
        self.assertEqual(Identity(self.c.path,PASSWORD).status()['revoked_nodes'],1)
        self.refusal('NODE_ALREADY_REGISTERED_OR_REVOKED',issue,self.c,self.n.public,self.n.id,NOW+5)
    def test_all_handles_closed_for_rename_delete(self):
        _,r=self.response(); accept(self.c,r,NOW+3)
        old=self.c.path/'registry.sqlite'; new=self.c.path/'renamed.sqlite'
        old.rename(new); new.unlink()
        self.assertFalse(new.exists())
    def test_network_not_used(self):
        with patch('socket.create_connection',side_effect=AssertionError('network')):
            _,r=self.response(); a=accept(self.c,r,NOW+3)
            confirm(self.n,self.c.public,self.c.id,a,NOW+4)
    def test_output_no_overwrite(self):
        f=self.root/'x.json'; write_doc(f,{'ok':True})
        self.refusal('OUTPUT_EXISTS',write_doc,f,{'bad':True})
        self.assertEqual(read_doc(f),{'ok':True})
    def test_cli_init_reopens_identity_and_exports_public_only(self):
        args=['init','--role','controller','--state',str(self.c.path),
              '--public-out',str(self.root/'pub.json'),'--report',str(self.root/'report.json')]
        with patch('hb_enroll.secret',return_value=PASSWORD.decode()), redirect_stdout(io.StringIO()):
            self.assertEqual(hb_enroll.main(args),0)
        report=read_doc(self.root/'report.json')
        self.assertFalse(report['created_new_identity']); self.assertTrue(report['identity_reopened_and_verified'])
        self.assertNotIn('PRIVATE KEY',(self.root/'pub.json').read_text())
    def test_cli_init_output_collision_refused(self):
        args=['init','--role','node','--state',str(self.root/'notmade'),
              '--public-out',str(self.root/'same.json'),'--report',str(self.root/'same.json')]
        self.refusal('OUTPUT_PATH_COLLISION',hb_enroll.main,args)
        self.assertFalse((self.root/'notmade').exists())

class BindingTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.path=self.root/'history.sqlite'; self.salt=secrets.token_bytes(32)
        self.raw=['user.example','worker01','machine-one']
        self.worker=hmac.new(self.salt,json.dumps(self.raw,separators=(',',':')).encode(),hashlib.sha256).hexdigest()
        with closing(sqlite3.connect(self.path)) as db:
            db.executescript('CREATE TABLE local_identity(id INTEGER PRIMARY KEY,salt BLOB);CREATE TABLE samples(worker TEXT,sampled INTEGER,profile TEXT,payload TEXT);')
            db.execute('INSERT INTO local_identity VALUES (1,?)',(self.salt,))
            db.execute('INSERT INTO samples VALUES (?,1,?,?)',(self.worker,'0'*64,'{}')); db.commit()
    def tearDown(self):self.tmp.cleanup()
    def test_binding_matches_accelerator_formula(self):
        b=history_binding(self.path,*self.raw); self.assertEqual(b['worker'],self.worker)
        self.assertEqual(b['assurance'],'operator_asserted_not_telemetry_attested')
    def test_history_byte_identical(self):
        before=self.path.read_bytes(); history_binding(self.path,*self.raw)
        self.assertEqual(before,self.path.read_bytes())
    def test_binding_never_exports_raw_tuple_or_salt(self):
        text=json.dumps(history_binding(self.path,*self.raw))
        for s in self.raw+[self.salt.hex()]: self.assertNotIn(s,text)
    def test_wrong_tuple_refused(self):
        with self.assertRaises(Refused) as e:history_binding(self.path,'other','worker01','machine-one')
        self.assertEqual(e.exception.code,'WORKER_NOT_IN_HISTORY')
    def test_no_history_created(self):
        missing=self.root/'missing.sqlite'
        with self.assertRaises(Refused): history_binding(missing,*self.raw)
        self.assertFalse(missing.exists())
    def test_invalid_schema(self):
        with closing(sqlite3.connect(self.path)) as db: db.execute('DROP TABLE samples'); db.commit()
        with self.assertRaises(Refused) as e: history_binding(self.path,*self.raw)
        self.assertEqual(e.exception.code,'HISTORY_SCHEMA')
    def test_absent_identity_not_regenerated(self):
        with closing(sqlite3.connect(self.path)) as db: db.execute('DELETE FROM local_identity'); db.commit()
        before=self.path.read_bytes()
        with self.assertRaises(Refused): history_binding(self.path,*self.raw)
        self.assertEqual(before,self.path.read_bytes())

class WireTests(unittest.TestCase):
    def test_duplicate_keys(self):
        with self.assertRaises(Refused): loads(b'{"a":1,"a":2}')
    def test_nan_and_float_refused(self):
        for raw in [b'{"a":NaN}',b'{"a":1.2}']:
            with self.subTest(raw=raw),self.assertRaises(Refused): loads(raw)
    def test_nonascii_wire_refused(self):
        with self.assertRaises(Refused): canonical({'a':'\u00e8'})
    def test_oversized_json(self):
        with self.assertRaises(Refused): loads(b' '*(MAX_BYTES+1))
    def test_message_domain_separation(self):
        key=Ed25519PrivateKey.generate(); d=sign(key,'challenge',{})
        with self.assertRaises(Refused): verify(d,key.public_key(),'response')
    def test_no_boolean_as_timestamp(self):
        with self.assertRaises(Refused): lifetime({'issued_at':True,'expires_at':50},2)
    def test_hash_is_order_independent(self):self.assertEqual(sha({'a':1,'b':2}),sha({'b':2,'a':1}))

if __name__=='__main__': unittest.main()
