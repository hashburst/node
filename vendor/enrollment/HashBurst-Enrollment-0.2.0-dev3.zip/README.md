# HashBurst Enrollment 0.2.0-dev3

## Scopo

Incremento separato da Accelerator 0.1.2 e Control Lab dev2: identita Ed25519
persistenti, cifrate, e registrazione di un nodo mediante documenti firmati.
Non e un altro simulatore: una chiave generata resta sulla macchina che la crea,
puo essere riaperta in processi successivi e identifica il partecipante al registro.
Il protocollo NON accetta comandi di mining. L'autorizzazione risultante vale solo
per il registro identita (`enrollment-read-only`). Non abilita l'applicazione di
configurazioni, l'esplorazione di nuovi profili o un servizio remoto.

Lo schema e il dominio di firma sono diversi da quelli del laboratorio.
Le chiavi `lab-only`, le identita HVM/TEP, i wallet e il sale di history.sqlite
non vengono importati, sostituiti o riutilizzati come chiavi di firma.

## Stato rispetto alla ricognizione

- Il risultato storico e spiegato: 53 worker senza un'alternativa modellabile,
  46 senza altro profilo osservato sullo stesso hardware e 10 senza un profilo
  corrente pronto. Questi gruppi non sono disgiunti.
- Il limite termico resta quello dell'operatore. Il report registra massimi
  normalizzati di 81-96 C per 61 decisioni; non verifica i sensori fisici e non
  conserva l'identificativo del sensore che ha determinato ogni massimo.
- Questo modulo non aspetta che compaia una raccomandazione economica per
  sviluppare l'identita del nodo. Non interpreta `hold` come arresto del miner.
- La raccolta/prezzo live continua con Run-Cycle.ps1 della dev2, in EUR.
  Non sono stati modificati file, database o policy della 0.1.2 o della dev2.

## Requisiti

Python >=3.10; percorso Windows gia utilizzato: Python 3.11.0, cryptography 50.0.2.
Il launcher Windows richiede la dipendenza gia presente e NON esegue pip.
Lo sviluppo e i test qui allegati sono stati eseguiti su Linux/Python 3.13.5/
cryptography 46.0.4. Il collaudo Windows del nuovo modulo e ancora da eseguire.

Su una macchina pilota senza ambiente predisposto creare un ambiente dedicato:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install --only-binary=:all: -r requirements.txt
.venv/bin/python -B -m unittest discover -s tests -v
```

Su Windows il corrispondente interprete e `.venv\Scripts\python.exe`.
Non installare un miner sul PC di sviluppo per eseguire questo modulo.

## Custodia delle chiavi

Una directory di stato contiene:

```
private-key.pem    # PRIVATO: PKCS8 cifrato con passphrase
public.json        # Documento pubblico autofirmato
registry.sqlite    # Registro locale riservato
```

Usare una passphrase lunga, unica, conservata in un password manager. Minimo
16 caratteri per la CLI; un minimo di lunghezza non e una garanzia di entropia.
Non usare password SSH, wallet seed o segreti API. Non passarla da riga di comando,
variabile di ambiente, file di report o chat. Viene richiesta con getpass;
se non e disponibile l'inserimento nascosto, la CLI si ferma.

Su POSIX lo stato richiede proprietario corrente e permessi 700/600.
Su Windows la creazione applica e verifica ACL locali per utente corrente e SYSTEM,
mediante un comando PowerShell fisso. E la sola operazione ausiliaria di sistema:
non riguarda i miner, i servizi, il registro Windows o le ACL di altre cartelle.
La passphrase non viene passata a PowerShell. E consigliata una console normale,
non un'esecuzione come amministratore.

La cifratura non protegge da malware attivo nello stesso account, da un
amministratore della macchina, dal furto della passphrase o dalla lettura della
memoria durante l'uso. Non sono implementati TPM, servizio non presidiato, KMS,
rotazione automatica, backup remoto, revoca distribuita o zeroizzazione garantita
in memoria Python. Non dichiarare il modulo pronto per l'esecuzione automatica.

Conservare un backup privato dell'intera directory di stato e la passphrase
separatamente. Non inviare la chiave, neppure cifrata, o registry.sqlite in chat.
La perdita dello stato non va risolta rigenerando silenziosamente l'identita.
Un ripristino da backup vecchio puo ripristinare anche nonce consumati: richiede
riconciliazione operativa; questo prototipo non ha un contatore monotono hardware.

## Primo passo: solo il controller, sul PC di sviluppo

Dopo la verifica SHA256 dello ZIP, dal percorso del pacchetto eseguire:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Start-Identity.ps1 `
  -Role controller `
  -StateDir "C:\Users\netse\HashBurst_Deployer\hb-controller-state" `
  -OutDir "C:\Users\netse\HashBurst_Deployer\controller-export-UNIVOCO" `
  -PythonPath "C:\Users\netse\HashBurst_Deployer\HashBurst-Control-Lab-0.2.0-dev1\.venv\Scripts\python.exe"
```

`OutDir` deve essere un percorso nuovo. Il launcher verifica il pacchetto, esegue
67 test e solo dopo richiede la passphrase. `hb-controller-state` e uno stato
persistente, non una cartella da cancellare dopo il collaudo. Se esiste gia,
la CLI lo riapre con la stessa passphrase e non rigenera le chiavi; un errore o
un ruolo differente interrompe l'operazione. Il report verifica la riapertura
della chiave cifrata. `active_nodes: 0` e il risultato iniziale corretto.

## Nodo pilota: generare la chiave SULLA macchina del miner

Scegliere un solo nodo amministrato dall'operatore. Trasferire solo il pacchetto
pubblico, non `hb-controller-state`. Nessun accesso SSH e automatizzato.
Il file ZIP ha lo stesso hash su entrambe le macchine. Con ambiente predisposto:

```powershell
& $Python .\hb_enroll.py init --role node --state .\hb-node-state `
  --public-out .\node-public.json --report .\node-identity-report.json
```

Linux equivalente:

```sh
.venv/bin/python hb_enroll.py init --role node --state ./hb-node-state \
  --public-out ./node-public.json --report ./node-identity-report.json
```

`$Python` deve essere il percorso dell'interprete Python della macchina pilota,
NON quello del PC di sviluppo. La directory padre deve esistere. Usare una
passphrase diversa dal controller. Non inizializzare un finto nodo sul PC di
sviluppo per rappresentare un miner remoto.

## Scambio e pinning esplicito

Trasferire `node-public.json` al controller e `controller-public.json` al nodo
mediante un canale amministrativo gia autenticato. Su ciascuna macchina:

```powershell
& $Python .\hb_enroll.py inspect-public --role node --file .\node-public.json
& $Python .\hb_enroll.py inspect-public --role controller --file .\controller-public.json
```

Confrontare le impronte complete con quelle visualizzate dal proprietario sulla
macchina che ha generato la chiave, usando un canale indipendente affidabile
(ad esempio la console locale o una sessione SSH gia verificata). Leggere il
fingerprint dallo stesso file appena ricevuto NON autentica da solo quel file.
Non approvare un host o una chiave solo perche ha un nome plausibile.

### 1. Controller: challenge vincolata al nodo atteso

```powershell
& $Python .\hb_enroll.py challenge --state $ControllerState `
  --node-public .\node-public.json --node-fingerprint $NodeFingerprint `
  --out .\challenge.json
```

La durata predefinita e 3600 secondi; `--ttl` ammette 60-86400 secondi.
La challenge e firmata e viene registrata prima dell'esportazione.
Un secondo tentativo mentre una challenge e ancora valida viene rifiutato:
non sostituire silenziosamente un documento in viaggio.

### Associazione opzionale allo storico esistente

Per la prima registrazione si puo aggiungere:

```powershell
--history "C:\Users\netse\HashBurst_Deployer\HashBurst-Mining-Accelerator-0.1.2\history.sqlite"
```

Il programma chiede i tre valori **esatti** `user`, `worker`, `machinename` della
sorgente RainbowMiner. Calcola l'HMAC con la stessa formula della 0.1.2 e verifica
che l'identificativo esista nella tabella samples. Legge il DB in sola lettura;
non modifica il sale, non inizializza tabelle e non aggiorna health o policy.
Mai copiare il sale sul nodo. I nomi raw non vengono scritti nei documenti.

Il campo risultante e sempre:
`operator_asserted_not_telemetry_attested`.
La corrispondenza storica NON dimostra che il nodo detentore della chiave ospiti
fisicamente quel worker. La firma NON certifica temperature, energia, hashrate,
proprieta dell'hardware o un'identita TEP/HVM. Sono necessari la verifica
operativa dell'operatore e, in un incremento successivo, un canale autenticato di
telemetria locale. Senza `--history` il nodo viene registrato esplicitamente
senza associazione al worker. Il modulo non aggiorna automaticamente un binding
esistente: serve una futura procedura approvata di modifica/rotazione.

### 2. Nodo: consenso limitato e risposta firmata

Trasferire challenge.json al nodo. Eseguire SUL NODO:

```powershell
& $Python .\hb_enroll.py respond --state $NodeState `
  --controller-public .\controller-public.json `
  --controller-fingerprint $ControllerFingerprint `
  --challenge .\challenge.json --consent-read-only --out .\response.json
```

Il consenso e solo al registro identita. Non consente mining, benchmark,
riavvii, aggiornamenti, overclock o cambi dei wallet. Il nodo non sostituisce un
controller gia registrato. La firma prova il possesso della chiave, non la
correttezza di tutte le affermazioni dell'operatore.

### 3. Controller: consumo una tantum e ricevuta firmata

Trasferire response.json al controller. Eseguire SUL CONTROLLER:

```powershell
& $Python .\hb_enroll.py accept --state $ControllerState `
  --response .\response.json --out .\ack.json
```

Verifica con la chiave del nodo salvata nella challenge, non con una chiave
arbitraria indicata nella risposta. Nonce, destinatario, scope, durata e consenso
devono corrispondere. Nonce consumato, inserimento del nodo e ricevuta sono
confermati nella stessa transazione SQLite. Le connessioni sono sempre chiuse.
La stessa risposta non puo produrre un'altra registrazione dopo un riavvio.

### 4. Nodo: verifica della conferma

Trasferire ack.json al nodo. Eseguire SUL NODO:

```powershell
& $Python .\hb_enroll.py confirm --state $NodeState `
  --controller-public .\controller-public.json `
  --controller-fingerprint $ControllerFingerprint `
  --ack .\ack.json --out .\node-enrollment-report.json
```

L'esito `identity_registry_confirmed: true` non cambia
`production_apply_supported: false`. Non cambia neppure
`telemetry_authenticated: false`: l'autenticazione della telemetria e un'attivita
distinta, non una conseguenza automatica della registrazione.

## Recupero di un export interrotto

Non cancellare il registro e non creare nuove chiavi. L'output non sovrascrive
file esistenti. Usare un nome nuovo per riesportare il documento conservato:

```powershell
& $Python .\hb_enroll.py export --state $ControllerState --kind challenge `
  --ref $Nonce --out .\challenge-export-2.json
& $Python .\hb_enroll.py export --state $ControllerState --kind ack `
  --ref $NodeFingerprint --out .\ack-export-2.json
```

Una nuova esecuzione di `respond` con la stessa challenge ancora valida restituisce
la stessa risposta conservata, senza nuovi eventi o firme. Una challenge scaduta
non viene ridatata: il controller deve emetterne una nuova.
Il tempo locale non puo arretrare rispetto all'ultimo evento del registro.
Le verifiche di tempo ammettono al massimo 30 secondi di disallineamento fra
macchine; mantenere gli orologi sincronizzati, non falsificare i timestamp.

## Revoca locale

```powershell
& $Python .\hb_enroll.py revoke --state $ControllerState `
  --node-fingerprint $NodeFingerprint --out .\revocation-report.json
```

Aggiorna soltanto il registro del controller. Non raggiunge il nodo remoto,
non spegne un miner e non annulla retroattivamente una ricevuta firmata.
L'impronta revocata non e riammessa automaticamente. Non e una revoca distribuita.

## Limiti e prosecuzione

- Nessun servizio in ascolto, SSH automatico, trasporto di rete o dispatch.
- Nessuna gestione di processi RainbowMiner; nessuna lettura delle sue credenziali.
- Nessuna delega operativa, strategia solo-mining o partizione nonce aggiunta.
- Nessun benchmark automatico e nessun cambiamento delle soglie termiche.
- Nessuna certificazione dell'hardware, sensore, stato HVM o blockchain.
- Nessuna fusione remota di PR o certificazione di release produzione.
- PKCS8 + passphrase e un primo meccanismo locale presidiato, non un key vault.

Il prossimo contratto funzionale e la telemetria firmata del nodo pilota con
identificativo dei dispositivi, origine e timestamp delle misure. Dopo quel
collegamento servono profili autorizzati e un adapter applicativo, con conferma e
rollback dei file/processi reali. Un'alternativa economica richiede dati o una
prova esplicitamente autorizzata; non viene inventata da questo modulo.

## Fonti tecniche

- https://cryptography.io/en/latest/hazmat/primitives/asymmetric/serialization/
- https://cryptography.io/en/latest/hazmat/primitives/asymmetric/ed25519/
- https://docs.python.org/3.11/library/sqlite3.html
- https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/icacls

Le fonti descrivono le primitive e i comportamenti delle librerie, non certificano
questa implementazione o un suo uso in produzione.
