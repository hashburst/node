param(
    [Parameter(Mandatory = $true)] [ValidateSet('controller','node')] [string] $Role,
    [Parameter(Mandatory = $true)] [string] $StateDir,
    [Parameter(Mandatory = $true)] [string] $OutDir,
    [Parameter(Mandatory = $true)] [string] $PythonPath
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Root = $PSScriptRoot
& "$Root\Verify-Package.ps1"
if (-not (Test-Path -LiteralPath $PythonPath -PathType Leaf)) {
    throw 'Interprete Python non trovato. Nessuna dipendenza viene installata automaticamente.'
}
& $PythonPath -c "import sys, cryptography; sys.exit(0 if sys.version_info >= (3,10) and cryptography.__version__ == '50.0.2' else 1)"
if ($LASTEXITCODE -ne 0) { throw 'Richiesti Python >=3.10 e cryptography 50.0.2 nell ambiente selezionato.' }
if (Test-Path -LiteralPath $OutDir) { throw 'Cartella export esistente: nessuna sovrascrittura.' }
if (-not (Test-Path -LiteralPath (Split-Path -Parent $StateDir) -PathType Container)) {
    throw 'La cartella padre dello stato deve esistere.'
}
& $PythonPath -B -m unittest discover -s "$Root\tests" -v
if ($LASTEXITCODE -ne 0) { throw 'Test falliti. Identita operativa non inizializzata.' }
New-Item -ItemType Directory -Path $OutDir -ErrorAction Stop | Out-Null
$Public = Join-Path $OutDir ($Role + '-public.json')
$Report = Join-Path $OutDir ($Role + '-identity-report.json')
& $PythonPath -B "$Root\hb_enroll.py" init --role "$Role" --state "$StateDir" --public-out "$Public" --report "$Report"
if ($LASTEXITCODE -ne 0) {
    throw 'Inizializzazione interrotta. Conservare lo stato; non cancellare o rigenerare chiavi.'
}
Write-Host "PUBLIC=$Public"
Write-Host "REPORT=$Report"
Write-Host 'La chiave privata rimane nello stato locale. Non caricare private-key.pem, registry.sqlite o la passphrase.'
