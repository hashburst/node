"""Strict, domain-separated enrollment messages; no control-command message type."""
from __future__ import annotations
import hashlib
import json
import re
from typing import Any
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

DOMAIN = b'HB-NODE-ENROLLMENT/v1\x00'
FORMAT = 'hb-node-enrollment-envelope-v1'
SCOPE = 'enrollment-read-only'
MAX_BYTES = 128 * 1024
MAX_INT = 2**53 - 1
HEX64 = re.compile(r'[0-9a-f]{64}\Z')
HEX128 = re.compile(r'[0-9a-f]{128}\Z')
KINDS = {'public', 'challenge', 'response', 'ack'}

class Refused(ValueError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)

def need(ok: bool, code: str) -> None:
    if not ok:
        raise Refused(code)

def _types(v: Any, depth: int = 0) -> None:
    need(depth <= 16, 'JSON_DEPTH')
    if v is None or type(v) is bool:
        return
    if type(v) is int:
        need(abs(v) <= MAX_INT, 'INTEGER_RANGE'); return
    if type(v) is str:
        need(len(v) <= 4096 and v.isascii() and all(ord(x) >= 32 for x in v), 'STRING_FORMAT'); return
    if type(v) is list:
        need(len(v) <= 128, 'LIST_SIZE')
        for x in v: _types(x, depth + 1)
        return
    if type(v) is dict:
        need(len(v) <= 64, 'OBJECT_SIZE')
        for k, x in v.items():
            need(type(k) is str, 'KEY_TYPE'); _types(k, depth + 1); _types(x, depth + 1)
        return
    raise Refused('JSON_TYPE')

def canonical(v: Any) -> bytes:
    # A deliberately restricted protocol; not an implementation of RFC 8785.
    _types(v)
    out = json.dumps(v, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False).encode('ascii')
    need(len(out) <= MAX_BYTES, 'JSON_SIZE')
    return out

def pairs(values):
    out = {}
    for k, v in values:
        need(k not in out, 'DUPLICATE_KEY'); out[k] = v
    return out

def loads(raw: bytes) -> dict:
    need(type(raw) is bytes and len(raw) <= MAX_BYTES, 'JSON_SIZE')
    try:
        obj = json.loads(raw.decode('ascii'), object_pairs_hook=pairs)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise Refused('JSON_INVALID') from exc
    canonical(obj)
    need(type(obj) is dict, 'OBJECT_REQUIRED')
    return obj

def sha(v: Any) -> str:
    return hashlib.sha256(canonical(v)).hexdigest()

def raw_public(key: Ed25519PublicKey) -> bytes:
    return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)

def key_id(key: Ed25519PublicKey) -> str:
    return hashlib.sha256(b'HB-NODE-IDENTITY/v1\x00' + raw_public(key)).hexdigest()

def hex64(v: Any, code: str = 'HEX_INVALID') -> str:
    need(type(v) is str and HEX64.fullmatch(v) is not None, code)
    return v

def sign(key: Ed25519PrivateKey, kind: str, payload: dict) -> dict:
    need(kind in KINDS, 'MESSAGE_KIND')
    body = {'format': FORMAT, 'algorithm': 'Ed25519', 'kind': kind,
            'key_id': key_id(key.public_key()), 'payload': payload}
    return dict(body, signature=key.sign(DOMAIN + canonical(body)).hex())

def verify(doc: dict, public: Ed25519PublicKey, kind: str) -> dict:
    canonical(doc)
    need(type(doc) is dict and set(doc) == {'format', 'algorithm', 'kind', 'key_id', 'payload', 'signature'}, 'ENVELOPE_SCHEMA')
    need(kind in KINDS and doc['format'] == FORMAT and doc['kind'] == kind and doc['algorithm'] == 'Ed25519', 'DOMAIN_MISMATCH')
    need(doc['key_id'] == key_id(public), 'SIGNER_MISMATCH')
    need(type(doc['signature']) is str and HEX128.fullmatch(doc['signature']) is not None, 'SIGNATURE_FORMAT')
    body = {k: v for k, v in doc.items() if k != 'signature'}
    try:
        public.verify(bytes.fromhex(doc['signature']), DOMAIN + canonical(body))
    except InvalidSignature as exc:
        raise Refused('SIGNATURE_INVALID') from exc
    need(type(doc['payload']) is dict, 'PAYLOAD_SCHEMA')
    return doc['payload']

def integer(v, minimum=0, maximum=MAX_INT):
    need(type(v) is int and minimum <= v <= maximum, 'INTEGER_INVALID')
    return v

def lifetime(p: dict, now: int, max_ttl: int = 86400) -> None:
    integer(now)
    a, b = integer(p.get('issued_at')), integer(p.get('expires_at'))
    need(0 < b - a <= max_ttl, 'TTL_INVALID')
    need(a <= now + 30, 'FUTURE_MESSAGE')
    need(now < b, 'EXPIRED')

def public_document(key: Ed25519PrivateKey, role: str, now: int) -> dict:
    need(role in ('controller', 'node'), 'ROLE_INVALID')
    integer(now)
    return sign(key, 'public', {'schema': 'hb-node-public-v1', 'scope': SCOPE,
                              'role': role, 'created_at': now,
                              'public_key': raw_public(key.public_key()).hex()})

def public_key(doc: dict, role: str, fingerprint: str | None = None) -> Ed25519PublicKey:
    canonical(doc)
    p = doc.get('payload')
    need(type(p) is dict and set(p) == {'schema', 'scope', 'role', 'created_at', 'public_key'}, 'PUBLIC_SCHEMA')
    need(p['schema'] == 'hb-node-public-v1' and p['scope'] == SCOPE and p['role'] == role, 'PUBLIC_ROLE_OR_SCOPE')
    integer(p['created_at'])
    key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(hex64(p['public_key'])))
    if fingerprint is not None:
        need(key_id(key) == hex64(fingerprint), 'PIN_MISMATCH')
    verify(doc, key, 'public')
    # Self-signing is NOT an external attestation. Caller supplies a separate pin.
    return key
