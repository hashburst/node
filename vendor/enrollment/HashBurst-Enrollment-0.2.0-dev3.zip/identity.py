"""Persistent encrypted identities and private local registry. No mining settings."""
from __future__ import annotations
from contextlib import closing, contextmanager
import base64
import os
from pathlib import Path
import secrets
import sqlite3
import stat
import subprocess
import sys
import time
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from wire import Refused, need, canonical, loads, sha, public_document, public_key, key_id

VERSION = '0.2.0-dev3'
SCHEMA_SQL = '''
CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE pending(nonce TEXT PRIMARY KEY, node_id TEXT NOT NULL, node_public TEXT NOT NULL,
                     challenge TEXT NOT NULL, expires INTEGER NOT NULL, used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE nodes(node_id TEXT PRIMARY KEY, node_public TEXT NOT NULL, binding_ns TEXT, worker TEXT,
                   registered INTEGER NOT NULL, revoked INTEGER NOT NULL DEFAULT 0,
                   response_sha TEXT NOT NULL, ack TEXT NOT NULL,
                   UNIQUE(binding_ns, worker));
CREATE TABLE responses(nonce TEXT PRIMARY KEY, controller_id TEXT NOT NULL, challenge_sha TEXT NOT NULL,
                       response TEXT NOT NULL);
CREATE TABLE controllers(key_id TEXT PRIMARY KEY, public_doc TEXT NOT NULL);
CREATE TABLE events(seq INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, at INTEGER NOT NULL, digest TEXT NOT NULL);
'''

def no_link(path: Path, must_exist: bool = True) -> Path:
    path = Path(path).absolute()
    try: s = path.lstat()
    except FileNotFoundError:
        if must_exist: raise Refused('PATH_MISSING')
        return path
    need(not stat.S_ISLNK(s.st_mode) and not (getattr(s, 'st_file_attributes', 0) & 0x400), 'LINK_OR_REPARSE_REFUSED')
    return path

def read_bytes(path: Path, maximum: int = 128 * 1024) -> bytes:
    path = no_link(path)
    need(path.is_file(), 'REGULAR_FILE_REQUIRED')
    with path.open('rb') as f: data = f.read(maximum + 1)
    need(len(data) <= maximum, 'FILE_TOO_LARGE')
    return data

def read_doc(path: Path) -> dict:
    return loads(read_bytes(path))

def write_new(path: Path, data: bytes) -> None:
    path = no_link(path, False)
    no_link(path.parent)
    # Never overwrite any exported document or operator file.
    try: fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc: raise Refused('OUTPUT_EXISTS') from exc
    with os.fdopen(fd, 'wb') as f:
        f.write(data); f.flush(); os.fsync(f.fileno())

def write_doc(path: Path, doc: dict) -> None:
    write_new(path, canonical(doc) + b'\n')

def _windows_acl(path: Path, create: bool) -> None:
    # Fixed local ACL operation, not a remote command or miner command.
    # Escape a literal path before encoding PowerShell UTF-16LE.
    literal = str(path).replace("'", "''")
    root = Path(os.environ.get('SystemRoot', r'C:\Windows'))
    shell = root / 'System32' / 'WindowsPowerShell' / 'v1.0' / 'powershell.exe'
    script = "$ErrorActionPreference='Stop'; $p='" + literal + "'; "
    script += "$sid=[System.Security.Principal.WindowsIdentity]::GetCurrent().User; "
    if create:
        script += '''
$a=[System.Security.AccessControl.DirectorySecurity]::new();
$a.SetAccessRuleProtection($true,$false); $a.SetOwner($sid);
foreach($s in @($sid.Value,'S-1-5-18')) {
$r=[System.Security.AccessControl.FileSystemAccessRule]::new(
  [System.Security.Principal.SecurityIdentifier]$s,
  [System.Security.AccessControl.FileSystemRights]::FullControl,
  [System.Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit',
  [System.Security.AccessControl.PropagationFlags]::None,
  [System.Security.AccessControl.AccessControlType]::Allow);
$a.AddAccessRule($r);
}
[System.IO.Directory]::SetAccessControl($p,$a);
'''
    script += '''
$a=Get-Acl -LiteralPath $p;
if(-not $a.AreAccessRulesProtected){throw 'ACL_NOT_PROTECTED'}
$items=@($p); $items+=@(Get-ChildItem -LiteralPath $p -Force | ForEach-Object { $_.FullName });
foreach($obj in $items) {
$acl=Get-Acl -LiteralPath $obj;
if($acl.GetOwner([System.Security.Principal.SecurityIdentifier]).Value -notin @($sid.Value,'S-1-5-18','S-1-5-32-544')) {throw 'ACL_OWNER'}
foreach($r in $acl.GetAccessRules($true,$true,[System.Security.Principal.SecurityIdentifier])) {
if($r.AccessControlType -eq 'Allow' -and $r.IdentityReference.Value -notin @($sid.Value,'S-1-5-18')) {throw 'ACL_TOO_BROAD'}
}
}
Write-Output 'ACL_PRIVATE_OK';
'''
    encoded = base64.b64encode(script.encode('utf-16-le')).decode('ascii')
    try:
        result = subprocess.run([str(shell), '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise Refused('WINDOWS_ACL_CHECK_FAILED') from exc
    need(result.returncode == 0 and b'ACL_PRIVATE_OK' in result.stdout, 'WINDOWS_ACL_CHECK_FAILED')

def private_directory(path: Path, create: bool = False) -> Path:
    path = no_link(path, not create)
    if create:
        no_link(path.parent)
        try: path.mkdir(mode=0o700)
        except FileExistsError as exc: raise Refused('STATE_EXISTS') from exc
    need(path.is_dir(), 'STATE_NOT_DIRECTORY')
    # Refuse linked entries even when checking the ACLs of an existing state.
    for item in path.iterdir(): no_link(item)
    if os.name == 'nt':
        _windows_acl(path, create)
    else:
        for p in [path, *path.iterdir()]:
            s = p.stat()
            need(s.st_uid == os.getuid() and stat.S_IMODE(s.st_mode) & 0o077 == 0, 'STATE_PERMISSIONS')
    return path

def password_bytes(value: bytes) -> bytes:
    need(type(value) is bytes and 16 <= len(value) <= 1024, 'PASSPHRASE_LENGTH')
    return value

class Identity:
    def __init__(self, directory: Path, password: bytes):
        self.path = private_directory(directory)
        self.public = read_doc(self.path / 'public.json')
        role = self.public.get('payload', {}).get('role')
        need(role in ('controller', 'node'), 'ROLE_INVALID')
        pub = public_key(self.public, role)
        pem = read_bytes(self.path / 'private-key.pem', 8192)
        need(pem.startswith(b'-----BEGIN ENCRYPTED PRIVATE KEY-----'), 'UNENCRYPTED_KEY_REFUSED')
        try:
            key = serialization.load_pem_private_key(pem, password=password_bytes(password))
        except (ValueError, TypeError) as exc:
            raise Refused('KEY_UNLOCK_FAILED') from exc
        need(isinstance(key, Ed25519PrivateKey), 'KEY_TYPE')
        need(key_id(key.public_key()) == key_id(pub), 'KEY_PUBLIC_MISMATCH')
        self.key, self.role, self.id = key, role, key_id(pub)
        with self.db() as db:
            meta = dict(db.execute('SELECT k,v FROM meta'))
            need(meta.get('schema') == 'hb-enrollment-registry-v1' and meta.get('key_id') == self.id
                 and meta.get('role') == self.role, 'REGISTRY_IDENTITY_MISMATCH')

    @classmethod
    def create(cls, directory: Path, role: str, password: bytes, now: int | None = None):
        need(role in ('controller', 'node'), 'ROLE_INVALID')
        password_bytes(password)
        path = Path(directory).absolute()
        if path.exists():
            old = cls(path, password)
            need(old.role == role, 'EXISTING_ROLE_MISMATCH')
            return old, False
        now = int(time.time()) if now is None else now
        need(type(now) is int and now >= 0, 'CLOCK_INVALID')
        path = private_directory(path, True)
        key = Ed25519PrivateKey.generate()
        pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                serialization.BestAvailableEncryption(password))
        public = public_document(key, role, now)
        write_new(path / 'private-key.pem', pem)
        write_doc(path / 'public.json', public)
        write_new(path / 'registry.sqlite', b'')
        with closing(sqlite3.connect(path / 'registry.sqlite')) as db:
            db.execute('PRAGMA journal_mode=DELETE')
            db.execute('PRAGMA synchronous=FULL')
            db.executescript(SCHEMA_SQL)
            db.executemany('INSERT INTO meta VALUES (?,?)', [('schema','hb-enrollment-registry-v1'),
                ('role',role), ('key_id', key_id(key.public_key())), ('last_event_at',str(now))])
            db.commit()
        # Reopen the encrypted key and DB before reporting success.
        return cls(path, password), True

    @contextmanager
    def db(self, write=False):
        path = no_link(self.path / 'registry.sqlite')
        uri = path.as_uri() + ('?mode=rw' if write else '?mode=ro')
        with closing(sqlite3.connect(uri, uri=True, timeout=5)) as db:
            db.execute('PRAGMA trusted_schema=OFF')
            db.execute('PRAGMA synchronous=FULL')
            if write:
                db.execute('BEGIN IMMEDIATE')
            else:
                db.execute('PRAGMA query_only=ON')
            try:
                yield db
                if write: db.commit()
            except BaseException:
                if write: db.rollback()
                raise

    def check_clock(self, db, now):
        need(type(now) is int and now >= 0, 'CLOCK_INVALID')
        previous = int(db.execute("SELECT v FROM meta WHERE k='last_event_at'").fetchone()[0])
        need(now >= previous, 'CLOCK_ROLLBACK')

    def event(self, db, kind, now, digest):
        self.check_clock(db, now)
        db.execute('INSERT INTO events(kind,at,digest) VALUES (?,?,?)', (kind,now,digest))
        db.execute("UPDATE meta SET v=? WHERE k='last_event_at'", (str(now),))

    def status(self):
        with self.db() as db:
            need(db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'REGISTRY_INTEGRITY')
            nodes = db.execute('SELECT count(*) FROM nodes WHERE revoked=0').fetchone()[0]
            revoked = db.execute('SELECT count(*) FROM nodes WHERE revoked=1').fetchone()[0]
            pending = db.execute('SELECT count(*) FROM pending WHERE used=0').fetchone()[0]
        return {'schema':'hb-enrollment-status-v1', 'version':VERSION, 'role':self.role,
                'public_fingerprint':self.id, 'private_key_encrypted':True, 'private_key_unlocked':True,
                'identity_persistent':True, 'registry_integrity':'ok', 'active_nodes':nodes,
                'revoked_nodes':revoked, 'unconsumed_challenges_including_expired':pending,
                'scope':'enrollment-read-only', 'network_calls':0,
                'telemetry_authenticated':False, 'production_apply_supported':False,
                'miner_configuration_modified':False, 'history_or_policy_modified':False}
