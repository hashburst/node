"""Read-only node enrollment by explicitly pinned signed files.

No transport, miner adapter, wallet API, or automatic resource authorization.
A telemetry binding is an operator assertion, NOT a proof about a physical sensor.
"""
from __future__ import annotations
from contextlib import closing
import hashlib
import hmac
import json
from pathlib import Path
import secrets
import sqlite3
from identity import Identity, no_link
from wire import (Refused, need, canonical, loads, sha, hex64, sign, verify,
                  public_key, key_id, integer, lifetime, SCOPE)

MAX_TTL = 86400

def validate_binding(binding):
    if binding is None: return
    need(type(binding) is dict and set(binding) == {'namespace', 'worker', 'assurance'}, 'BINDING_SCHEMA')
    hex64(binding['namespace']); hex64(binding['worker'])
    need(binding['assurance'] == 'operator_asserted_not_telemetry_attested', 'BINDING_ASSURANCE')

def history_binding(path: Path, user: str, worker: str, machine: str):
    """Read only the existing HMAC namespace and verify a declared tuple exists.

    Raw source names and namespace salt are never written into exported documents.
    This does not prove that the node holding the signing key hosts that worker.
    """
    identity = [user, worker, machine]
    need(all(type(s) is str and 0 < len(s) <= 512 for s in identity), 'IDENTITY_TUPLE_INVALID')
    path = no_link(path)
    need(path.is_file(), 'HISTORY_MISSING')
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=5)) as db:
        db.execute('PRAGMA query_only=ON'); db.execute('PRAGMA trusted_schema=OFF')
        schema = dict(db.execute("SELECT name,type FROM sqlite_master WHERE type IN ('table','view')"))
        need(schema.get('local_identity') == 'table' and schema.get('samples') == 'table', 'HISTORY_SCHEMA')
        need([r[1] for r in db.execute('PRAGMA table_info(local_identity)')] == ['id','salt'], 'HISTORY_SCHEMA')
        need([r[1] for r in db.execute('PRAGMA table_info(samples)')] == ['worker','sampled','profile','payload'], 'HISTORY_SCHEMA')
        rows = db.execute('SELECT id,salt FROM local_identity').fetchall()
        need(len(rows) == 1 and rows[0][0] == 1 and type(rows[0][1]) is bytes and len(rows[0][1]) == 32, 'HISTORY_IDENTITY')
        salt = rows[0][1]
        # Byte-for-byte formula used by Accelerator 0.1.2; no new salt is created.
        raw = json.dumps(identity, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
        pseudonym = hmac.new(salt, raw, hashlib.sha256).hexdigest()
        need(db.execute('SELECT 1 FROM samples WHERE worker=? LIMIT 1', (pseudonym,)).fetchone() is not None, 'WORKER_NOT_IN_HISTORY')
        namespace = hmac.new(salt, b'HB-ENROLLMENT-HISTORY-NAMESPACE/v1', hashlib.sha256).hexdigest()
    return {'namespace':namespace, 'worker':pseudonym, 'assurance':'operator_asserted_not_telemetry_attested'}

def challenge_payload(p, now):
    need(type(p) is dict and set(p) == {'schema','scope','nonce','controller_id','node_id','issued_at','expires_at','binding'}, 'CHALLENGE_SCHEMA')
    need(p['schema'] == 'hb-node-challenge-v1' and p['scope'] == SCOPE, 'CHALLENGE_SCOPE')
    for k in ('nonce','controller_id','node_id'): hex64(p[k])
    validate_binding(p['binding']); lifetime(p, now, MAX_TTL)

def response_payload(p, challenge, now):
    need(type(p) is dict and set(p) == {'schema','scope','nonce','controller_id','node_id','issued_at','expires_at',
                                      'binding','challenge_sha256','consent'}, 'RESPONSE_SCHEMA')
    need(p['schema'] == 'hb-node-response-v1' and p['scope'] == SCOPE and p['consent'] is True, 'READ_ONLY_CONSENT_REQUIRED')
    c = challenge['payload']
    for k in ('nonce','controller_id','node_id','binding','expires_at'):
        need(p[k] == c[k], 'RESPONSE_CHALLENGE_MISMATCH')
    need(p['challenge_sha256'] == sha(challenge), 'RESPONSE_CHALLENGE_MISMATCH')
    lifetime(p, now, MAX_TTL)
    need(p['issued_at'] >= c['issued_at'] - 30, 'RESPONSE_BEFORE_CHALLENGE')
    validate_binding(p['binding'])

def _unused_node(db, node_id):
    need(db.execute('SELECT 1 FROM nodes WHERE node_id=?', (node_id,)).fetchone() is None, 'NODE_ALREADY_REGISTERED_OR_REVOKED')

def issue(controller: Identity, node_doc: dict, expected_node: str, now: int, ttl=3600, binding=None):
    need(controller.role == 'controller', 'CONTROLLER_REQUIRED')
    node_key = public_key(node_doc, 'node', expected_node)
    integer(ttl, 60, MAX_TTL); validate_binding(binding); integer(now)
    payload = {'schema':'hb-node-challenge-v1', 'scope':SCOPE, 'nonce':secrets.token_hex(32),
               'controller_id':controller.id, 'node_id':key_id(node_key),
               'issued_at':now, 'expires_at':now + ttl, 'binding':binding}
    challenge = sign(controller.key, 'challenge', payload)
    with controller.db(True) as db:
        controller.check_clock(db, now); _unused_node(db, payload['node_id'])
        need(db.execute('SELECT 1 FROM pending WHERE node_id=? AND used=0 AND expires>?',
                        (payload['node_id'],now)).fetchone() is None, 'PENDING_CHALLENGE_EXISTS')
        if binding is not None:
            need(db.execute('SELECT 1 FROM nodes WHERE binding_ns=? AND worker=?',
                            (binding['namespace'],binding['worker'])).fetchone() is None, 'WORKER_ALREADY_BOUND')
        db.execute('INSERT INTO pending VALUES (?,?,?,?,?,0)', (payload['nonce'],payload['node_id'],
                   canonical(node_doc).decode(),canonical(challenge).decode(),payload['expires_at']))
        controller.event(db, 'challenge_issued', now, sha(challenge))
    return challenge

def respond(node: Identity, controller_doc: dict, expected_controller: str, challenge: dict,
            now: int, consent: bool):
    need(node.role == 'node', 'NODE_REQUIRED')
    need(consent is True, 'READ_ONLY_CONSENT_REQUIRED')
    ctl_key = public_key(controller_doc, 'controller', expected_controller)
    c = verify(challenge, ctl_key, 'challenge'); challenge_payload(c, now)
    need(c['controller_id'] == key_id(ctl_key) and c['node_id'] == node.id, 'WRONG_RECIPIENT')
    with node.db(True) as db:
        node.check_clock(db, now)
        trusted = db.execute('SELECT key_id FROM controllers').fetchall()
        need(not trusted or [x[0] for x in trusted] == [key_id(ctl_key)], 'OTHER_CONTROLLER_ALREADY_PINNED')
        old = db.execute('SELECT challenge_sha,response FROM responses WHERE nonce=?', (c['nonce'],)).fetchone()
        if old:
            need(old[0] == sha(challenge), 'NONCE_REUSED')
            return loads(old[1].encode())  # Idempotent export, no new consent or event.
        p = {'schema':'hb-node-response-v1', 'scope':SCOPE, 'nonce':c['nonce'],
             'controller_id':c['controller_id'], 'node_id':node.id, 'issued_at':now,
             'expires_at':c['expires_at'], 'binding':c['binding'], 'consent':True,
             'challenge_sha256':sha(challenge)}
        response = sign(node.key, 'response', p)
        db.execute('INSERT OR IGNORE INTO controllers VALUES (?,?)', (key_id(ctl_key),canonical(controller_doc).decode()))
        db.execute('INSERT INTO responses VALUES (?,?,?,?)', (c['nonce'],key_id(ctl_key),sha(challenge),canonical(response).decode()))
        node.event(db, 'read_only_consent', now, sha(response))
    return response

def accept(controller: Identity, response: dict, now: int):
    need(controller.role == 'controller', 'CONTROLLER_REQUIRED')
    canonical(response)
    p = response.get('payload')
    need(type(p) is dict, 'RESPONSE_SCHEMA')
    nonce = hex64(p.get('nonce'))
    with controller.db(True) as db:
        controller.check_clock(db, now)
        row = db.execute('SELECT node_id,node_public,challenge,expires,used FROM pending WHERE nonce=?',(nonce,)).fetchone()
        need(row is not None, 'UNKNOWN_CHALLENGE')
        need(row[4] == 0, 'CHALLENGE_ALREADY_CONSUMED')
        node_doc, challenge = loads(row[1].encode()), loads(row[2].encode())
        c = verify(challenge, controller.key.public_key(), 'challenge'); challenge_payload(c, now)
        node_key = public_key(node_doc, 'node', row[0])
        p = verify(response, node_key, 'response'); response_payload(p, challenge, now)
        _unused_node(db, row[0])
        binding = p['binding']
        ns, worker = (binding['namespace'],binding['worker']) if binding else (None,None)
        if binding:
            need(db.execute('SELECT 1 FROM nodes WHERE binding_ns=? AND worker=?',(ns,worker)).fetchone() is None, 'WORKER_ALREADY_BOUND')
        ack_payload = {'schema':'hb-node-ack-v1', 'scope':SCOPE, 'nonce':nonce,
                       'controller_id':controller.id, 'node_id':row[0], 'registered_at':now,
                       'binding':binding, 'response_sha256':sha(response),
                       'authorization':'identity_registry_only', 'production_apply_supported':False}
        ack = sign(controller.key, 'ack', ack_payload)
        db.execute('INSERT INTO nodes VALUES (?,?,?,?,?,0,?,?)', (row[0],row[1],ns,worker,now,sha(response),canonical(ack).decode()))
        db.execute('UPDATE pending SET used=1 WHERE nonce=?',(nonce,))
        controller.event(db, 'node_registered_read_only', now, sha(ack))
    return ack

def confirm(node: Identity, controller_doc: dict, expected_controller: str, ack: dict, now: int):
    need(node.role == 'node', 'NODE_REQUIRED')
    ctl = public_key(controller_doc, 'controller', expected_controller)
    p = verify(ack, ctl, 'ack')
    need(set(p) == {'schema','scope','nonce','controller_id','node_id','registered_at','binding',
                    'response_sha256','authorization','production_apply_supported'}, 'ACK_SCHEMA')
    need(p['schema'] == 'hb-node-ack-v1' and p['scope'] == SCOPE and p['authorization'] == 'identity_registry_only'
         and p['production_apply_supported'] is False, 'ACK_SCOPE')
    for k in ('nonce','controller_id','node_id','response_sha256'): hex64(p[k])
    need(p['node_id'] == node.id and p['controller_id'] == key_id(ctl), 'WRONG_RECIPIENT')
    need(integer(p['registered_at']) <= now + 30, 'FUTURE_ACK'); validate_binding(p['binding'])
    with node.db(True) as db:
        node.check_clock(db, now)
        trusted = db.execute('SELECT 1 FROM controllers WHERE key_id=?',(key_id(ctl),)).fetchone()
        need(trusted is not None, 'CONTROLLER_NOT_PINNED')
        r = db.execute('SELECT response FROM responses WHERE nonce=?',(p['nonce'],)).fetchone()
        need(r is not None, 'NO_LOCAL_CONSENT')
        original = loads(r[0].encode())
        need(p['registered_at'] >= original['payload']['issued_at'] - 30, 'ACK_BEFORE_CONSENT')
        need(p['response_sha256'] == sha(original) and p['binding'] == original['payload']['binding'], 'ACK_RESPONSE_MISMATCH')
        old = db.execute('SELECT v FROM meta WHERE k=?',('ack:'+p['nonce'],)).fetchone()
        if old: need(old[0] == sha(ack), 'ACK_CONFLICT')
        else:
            db.execute('INSERT INTO meta VALUES (?,?)',('ack:'+p['nonce'],sha(ack)))
            node.event(db,'registration_acknowledged',now,sha(ack))
    return {'schema':'hb-enrollment-confirmation-v1', 'scope':SCOPE, 'identity_registry_confirmed':True,
            'worker_binding_present':p['binding'] is not None,
            'binding_assurance':p['binding']['assurance'] if p['binding'] else 'not_bound',
            'telemetry_authenticated':False, 'production_apply_supported':False,
            'network_calls':0, 'miner_configuration_modified':False}

def revoke(controller: Identity, node_id: str, now: int):
    need(controller.role == 'controller', 'CONTROLLER_REQUIRED'); hex64(node_id)
    with controller.db(True) as db:
        controller.check_clock(db, now)
        row = db.execute('SELECT revoked FROM nodes WHERE node_id=?',(node_id,)).fetchone()
        need(row is not None, 'NODE_NOT_REGISTERED')
        if row[0] == 0:
            db.execute('UPDATE nodes SET revoked=1 WHERE node_id=?',(node_id,))
            controller.event(db,'local_registration_revoked',now,sha({'node_id':node_id}))
    return {'revoked_locally':True,'remote_notification_sent':False,'production_apply_supported':False}

def export_saved(identity: Identity, kind: str, ref: str):
    hex64(ref)
    if kind == 'challenge':
        need(identity.role == 'controller','CONTROLLER_REQUIRED')
        sql = 'SELECT challenge FROM pending WHERE nonce=?'
    elif kind == 'ack':
        need(identity.role == 'controller','CONTROLLER_REQUIRED')
        sql = 'SELECT ack FROM nodes WHERE node_id=?'
    else:
        raise Refused('EXPORT_KIND')
    with identity.db() as db:
        row = db.execute(sql,(ref,)).fetchone()
        need(row is not None, 'DOCUMENT_NOT_FOUND')
    return loads(row[0].encode())
